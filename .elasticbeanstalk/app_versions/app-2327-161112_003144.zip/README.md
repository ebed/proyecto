# README


Para trabajar: se debe manejar una branch para desarrollar. Una vez terminada la funcionalidad, se integrará el master en la branch propia y luego se pondrá en el Master para asegurar funcionamiento del merge.



Información de la versión utilizada:

Rails version: 5.0.0
Ruby version: 2.3.1 (x86_64-linux) 



ESta es la documentacion de la gema de los formularios
https://github.com/bootstrap-ruby/rails-bootstrap-forms

Para la autenticación se utiliza Devise
https://github.com/plataformatec/devise

La gema de bootstrap
https://github.com/seyhunak/twitter-bootstrap-rails

PAra la paginación se está usando la gema will_paginate
https://github.com/mislav/will_paginate
http://mislav.github.io/will_paginate/

Para el editor html, se utiliza la gema CKEDITOR
https://github.com/galetahub/ckeditor






******************

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
