app.controller('footAppController',['$rootScope','$scope','$animate','$resource' ,'Scores', function($rootScope,$scope,$animate,$resource,  Scores) {

}]);
