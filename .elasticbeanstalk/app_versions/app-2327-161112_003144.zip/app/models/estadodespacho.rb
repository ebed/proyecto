class Estadodespacho < ApplicationRecord
  has_many :despachos
end
