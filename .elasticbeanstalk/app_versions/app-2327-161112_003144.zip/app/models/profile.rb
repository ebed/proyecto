class Profile < ApplicationRecord
  has_many :users
end
