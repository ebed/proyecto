class Tipobanner < ApplicationRecord
  has_many :banners
end
