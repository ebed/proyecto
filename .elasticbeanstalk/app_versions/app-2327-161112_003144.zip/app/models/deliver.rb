class Deliver < ApplicationRecord
  belongs_to :main_order

end
