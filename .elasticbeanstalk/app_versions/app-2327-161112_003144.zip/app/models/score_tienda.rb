class ScoreTienda < ApplicationRecord
  belongs_to :tienda
  belongs_to :user

end
