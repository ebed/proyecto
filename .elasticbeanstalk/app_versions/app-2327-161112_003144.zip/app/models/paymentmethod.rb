class Paymentmethod < ApplicationRecord
  has_many :payments
end
