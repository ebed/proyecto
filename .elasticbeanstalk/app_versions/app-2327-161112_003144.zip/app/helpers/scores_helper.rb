module ScoresHelper
end
