module SegmentsHelper
end
