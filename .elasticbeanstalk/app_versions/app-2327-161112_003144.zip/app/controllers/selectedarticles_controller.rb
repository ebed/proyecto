class SelectedarticlesController < ApplicationController

  def index

  end




end
