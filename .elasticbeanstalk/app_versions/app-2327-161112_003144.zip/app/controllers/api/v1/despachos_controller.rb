module Api
  module V1
    class DespachosController <  ApiController

      def show

      end

    end
  end
end
