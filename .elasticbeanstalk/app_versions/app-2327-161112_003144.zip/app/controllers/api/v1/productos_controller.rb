module Api
  module V1
    class ProductosController <  ApiController

      def index

      end


    end
  end
end
